import bpy,os,math,random,time
s=bpy.context.scene
# 10-second blocking retimed to8seconds, preserving all action and ascent.
for ob in bpy.data.objects:
 if ob.animation_data and ob.animation_data.action:
  for fc in ob.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.co.x=1+(k.co.x-1)*191/239;k.handle_left.x=k.co.x;k.handle_right.x=k.co.x
s.frame_end=192
m=bpy.data.materials['Silver mist'];ns=m.node_tree.nodes;tex=next(n for n in ns if n.type=='TEX_NOISE');geo=ns.new('ShaderNodeNewGeometry');m.node_tree.links.new(geo.outputs['Position'],tex.inputs['Vector']);tex.inputs['Scale'].default_value=.18
# Sparse billowing cloud banks, genuine3Dvolumes ratherthan flatbackground.
cloud=bpy.data.materials.new('High cloud billows');cloud.use_nodes=True;n=cloud.node_tree.nodes;n.clear();out=n.new('ShaderNodeOutputMaterial');v=n.new('ShaderNodeVolumePrincipled');v.inputs['Color'].default_value=(.62,.72,.78,1);v.inputs['Anisotropy'].default_value=.35
tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=3.6;tex.inputs['Detail'].default_value=3;coord=n.new('ShaderNodeTexCoord');cloud.node_tree.links.new(coord.outputs['Generated'],tex.inputs['Vector']);r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.40;r.color_ramp.elements[0].color=(0,0,0,1);r.color_ramp.elements[1].position=.68;r.color_ramp.elements[1].color=(.12,.12,.12,1);cloud.node_tree.links.new(tex.outputs['Fac'],r.inputs[0]);cloud.node_tree.links.new(r.outputs[0],v.inputs['Density']);cloud.node_tree.links.new(v.outputs[0],out.inputs['Volume'])
for pos,scale in [((-12,5,11),(9,5,2.5)),((7,6,17),(8,5,3)),((-7,-1,7),(7,3,1.3))]:
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,location=pos);o=bpy.context.object;o.name='Billowing cloud';o.scale=scale;o.data.materials.append(cloud)
# Smooth silhouette for rock forms while preserving the existing weatheredsurface.
for ob in bpy.data.objects:
 if ob.name.startswith('Basalt outcrop'):
  mod=ob.modifiers.new('Rock silhouette polish','SUBSURF');mod.levels=1;mod.render_levels=1
s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.frame_set(192)
out=os.path.dirname(bpy.data.filepath);bpy.ops.wm.save_as_mainfile(filepath=out+'/Mio_Dragon_Ascension_FILM.blend');s.render.resolution_percentage=65;s.render.filepath=out+'/cloud_end.png';tm=time.time();bpy.ops.render.render(write_still=True);print('VERIFY_SECONDS',time.time()-tm,flush=True)
