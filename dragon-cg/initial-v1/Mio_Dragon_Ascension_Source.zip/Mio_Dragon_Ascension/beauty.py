import bpy,os,time
from mathutils import Vector
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.use_denoising=False;s.cycles.samples=48;s.render.resolution_percentage=65
bpy.data.materials['Oxidised jade scales'].node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value=.28
bpy.data.materials['Old bronze ridges'].node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value=.55

for ob in bpy.data.objects:
 if ob.name.startswith('Amber eye') or ob.name.startswith('Vertical pupil'):ob.scale*=.6
 if ob.name.startswith('Nasal crown'):ob.scale*=.6
 if ob.name.startswith('Fang'):ob.hide_render=True
bpy.data.materials['Wet basalt'].node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.7
s.frame_set(85);cam=s.camera;cam.animation_data_clear();cam.location=(7,-12,3.5);cam.rotation_euler=(Vector((-2,0,2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=42
s.render.filepath=os.path.dirname(bpy.data.filepath)+'/beauty.png';t=time.time();bpy.ops.render.render(write_still=True);print('SECONDS',time.time()-t)
