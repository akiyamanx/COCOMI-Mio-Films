#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python - <<'PY'
from pathlib import Path
missing=[i for i in range(1,193) if not Path(f'frames/{i:04}.png').is_file()]
assert not missing, f'Missing frames: {missing}'
PY
ffmpeg -hide_banner -y -framerate 24 -start_number 1 -i frames/%04d.png -i dragon_sound.wav -filter_complex '[0:v]fade=t=in:st=0:d=0.3,fade=t=out:st=7.55:d=0.45[v];[1:a]afade=t=in:st=0:d=0.15,afade=t=out:st=7.5:d=0.5[a]' -map '[v]' -map '[a]' -frames:v 192 -c:v libx264 -preset slow -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart -t 8 Mio_Dragon_Ascension.mp4
ffprobe -v error -count_frames -show_entries stream=codec_name,codec_type,width,height,r_frame_rate,nb_read_frames,duration -show_entries format=duration,size -of json Mio_Dragon_Ascension.mp4 > video_validation.json
ffmpeg -v error -i Mio_Dragon_Ascension.mp4 -f null - 2> decode_validation.log
