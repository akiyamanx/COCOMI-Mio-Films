import bpy,os,time
s=bpy.context.scene
for o in bpy.data.objects:
 if o.name.startswith('Basalt outcrop') and o.location.y< -3.5:o.hide_render=True
 if o.name=='Plane':o.scale=(10,10,10)
# Modulate a low-density bounded volume rather than a uniform grey veil.
m=bpy.data.materials['Silver mist'];n=m.node_tree.nodes;p=n.get('Principled Volume');tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=.11;tex.inputs['Detail'].default_value=2
coord=n.new('ShaderNodeTexCoord');m.node_tree.links.new(coord.outputs['Object'],tex.inputs['Vector']);r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.30;r.color_ramp.elements[0].color=(.0008,.0008,.0008,1);r.color_ramp.elements[1].position=.75;r.color_ramp.elements[1].color=(.012,.012,.012,1);m.node_tree.links.new(tex.outputs['Fac'],r.inputs[0]);m.node_tree.links.new(r.outputs[0],p.inputs['Density'])
s.frame_set(1);s.render.resolution_percentage=100;s.eevee.taa_render_samples=32
out=os.path.dirname(bpy.data.filepath);bpy.ops.wm.save_as_mainfile(filepath=out+'/Mio_Dragon_Ascension_FINAL.blend');s.render.filepath=out+'/final_720.png';t=time.time();bpy.ops.render.render(write_still=True);print('BENCHMARK_SECONDS',time.time()-t,flush=True)
