import bpy, math, os, time
from mathutils import Vector
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=32;s.render.resolution_percentage=100
for name,metal in [('Oxidised jade scales',.28),('Old bronze ridges',.5)]:bpy.data.materials[name].node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value=metal
bpy.data.materials['Wet basalt'].node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.72
for ob in bpy.data.objects:
 if ob.name.startswith('Amber eye') or ob.name.startswith('Vertical pupil'):ob.scale*=.6
 if ob.name.startswith('Nasal crown'):ob.scale*=.6
 if ob.name.startswith('Fang'):ob.hide_render=True
 if ob.name.startswith('Cheek') and ob.type=='MESH':ob.data.materials.clear();ob.data.materials.append(bpy.data.materials['Oxidised jade scales'])
w=s.world;w.use_nodes=True;n=w.node_tree.nodes;n.clear();o=n.new('ShaderNodeOutputWorld');bg=n.new('ShaderNodeBackground');sky=n.new('ShaderNodeTexSky');sky.sky_type='NISHITA';sky.sun_elevation=.12;sky.sun_rotation=2.2;sky.air_density=1.4;sky.dust_density=4;bg.inputs['Strength'].default_value=.18;w.node_tree.links.new(sky.outputs['Color'],bg.inputs['Color']);w.node_tree.links.new(bg.outputs[0],o.inputs['Surface'])
# Reshape camera blocking: ground-level revelation, rising three-quarter pursuit, widening sky exit.
root=bpy.data.objects['DRAGON flight'];root.animation_data_clear();cam=s.camera;cam.animation_data_clear();cam.data.lens=43
for f in range(1,241,4):
 t=(f-1)/239;root.location=(t*2,0,-1.5+t*t*17);root.rotation_euler=(0,-t*.7,t*.2);root.keyframe_insert('location',frame=f);root.keyframe_insert('rotation_euler',frame=f)
 cam.location=(8-t*7,-15-t*7,1+t*15);target=Vector((-3.5+t*1.5,0,-.3+t*t*15));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f)
# Keep original fluid vertebral animation. Frame240 repeats last keyframe237 only3frames.
for ob in [root,cam]:
 for fc in ob.animation_data.action.fcurves:
  for k in fc.keyframe_points:k.interpolation='LINEAR'
s.render.image_settings.file_format='PNG';s.render.film_transparent=False
out=os.path.dirname(bpy.data.filepath);bpy.ops.wm.save_as_mainfile(filepath=out+'/Mio_Dragon_Ascension_FINAL.blend')
for f in [1,120,240]:
 s.frame_set(f);s.render.resolution_percentage=65;s.render.filepath=out+'/keyframe_%03d.png'%f;start=time.time();bpy.ops.render.render(write_still=True);print('FRAME_SECONDS',f,time.time()-start,flush=True)
