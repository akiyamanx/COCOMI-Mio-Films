import bpy,os,time,math
s=bpy.context.scene;out=os.path.dirname(bpy.data.filepath);frames=out+'/frames';os.makedirs(frames,exist_ok=True)
# Distant irregular ridge closes the flat horizon without hiding the subject.
if 'Distant basalt ridge' not in bpy.data.objects:
 vs=[];faces=[];nx=70;ny=30
 for j in range(ny):
  y=20+j*3
  for i in range(nx):
   x=-130+i*4;z=-3+(.5+.5*math.sin(x*.14)+.35*math.sin(x*.33+y*.12))**2*9+3*math.sin(y*.16);vs.append((x,y,z))
 for j in range(ny-1):
  for i in range(nx-1):a=j*nx+i;faces.append((a,a+1,a+1+nx,a+nx))
 me=bpy.data.meshes.new('Distant basalt ridge');me.from_pydata(vs,[],faces);me.update();ob=bpy.data.objects.new('Distant basalt ridge',me);bpy.context.collection.objects.link(ob);ob.data.materials.append(bpy.data.materials['Wet basalt'])
 for p in me.polygons:p.use_smooth=True
ridge=bpy.data.objects['Distant basalt ridge']
if not ridge.modifiers:
 mod=ridge.modifiers.new('Soft distant ridgeline','SUBSURF');mod.levels=2;mod.render_levels=2
m=bpy.data.materials.get('Distant haze') or bpy.data.materials.new('Distant haze');m.diffuse_color=(.10,.13,.15,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.10,.13,.15,1);p.inputs['Roughness'].default_value=1;ridge.data.materials.clear();ridge.data.materials.append(m)
s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.fps=24;s.frame_end=192
bpy.ops.wm.save_as_mainfile(filepath=out+'/Mio_Dragon_Ascension_FILM.blend')
for f in range(1,193):
 p=frames+'/%04d.png'%f
 if os.path.exists(p):continue
 s.frame_set(f);s.render.filepath=p;start=time.time();bpy.ops.render.render(write_still=True);print('FRAME_DONE',f,'SECONDS',round(time.time()-start,2),flush=True)
print('ALL_FRAMES_DONE',flush=True)
