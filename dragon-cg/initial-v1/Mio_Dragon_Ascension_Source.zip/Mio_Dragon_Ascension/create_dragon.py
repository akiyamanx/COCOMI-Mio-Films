import bpy, math, random, os, sys, time
from mathutils import Vector
from math import sin, cos, pi
random.seed(24)
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
sc=bpy.context.scene
sc.render.engine='CYCLES';sc.cycles.samples=64;sc.cycles.use_denoising=False;sc.cycles.max_bounces=4
sc.render.resolution_x=1280;sc.render.resolution_y=720;sc.render.resolution_percentage=65
sc.render.image_settings.file_format='PNG';sc.render.fps=24;sc.frame_end=240
sc.world.color=(.035,.045,.06)
sc.view_settings.view_transform='AgX'
def mat(name,col,metal=0,rough=.4,noise=False):
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if noise:
  n=m.node_tree.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=24;n.inputs['Detail'].default_value=3
  b=m.node_tree.nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=.28;b.inputs['Distance'].default_value=.08;m.node_tree.links.new(n.outputs['Fac'],b.inputs['Height']);m.node_tree.links.new(b.outputs['Normal'],p.inputs['Normal'])
 return m
jade=mat('Oxidised jade scales',(.045,.15,.13),.65,.28,True);dark=mat('Deep teal hide',(.012,.043,.04),.25,.45,True);gold=mat('Old bronze ridges',(.36,.19,.065),.72,.28,True);ivory=mat('Weathered horn',(.35,.29,.18),.3,.34,True);belly=mat('Belly armour',(.17,.24,.18),.5,.32);black=mat('Obsidian pupil',(.001,.003,.003),.35,.15)
eye=mat('Molten amber iris',(.8,.24,.025),.15,.22);p=eye.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(1,.22,.01,1);p.inputs['Emission Strength'].default_value=.35
rock=mat('Wet basalt',(.027,.04,.045),.2,.36,True)
def uv(name,loc,scale,ma,segments=16,rings=10,parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(ma)
 for p in o.data.polygons:p.use_smooth=True
 if parent:o.parent=parent
 return o
def curve(name,pts,radius,ma,parent=None):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=10;c.bevel_depth=radius;c.bevel_resolution=2;s=c.splines.new('BEZIER');s.bezier_points.add(len(pts)-1)
 for p,co in zip(s.bezier_points,pts):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(ma)
 if parent:o.parent=parent
 return o
def horn(name,pts,radii,ma,parent=None):
 vs=[];faces=[];N=9
 for i,p in enumerate(pts):
  v=Vector(p);d=Vector(pts[min(i+1,len(pts)-1)])-Vector(pts[max(0,i-1)]);q=d.to_track_quat('Z','Y')
  for j in range(N):vs.append(v+q@Vector((radii[i]*cos(j*2*pi/N),radii[i]*sin(j*2*pi/N),0)))
 for i in range(len(pts)-1):
  for j in range(N):a=i*N+j;b=i*N+(j+1)%N;faces.append((a,b,b+N,a+N))
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.data.materials.append(ma)
 for p in me.polygons:p.use_smooth=True
 if parent:o.parent=parent
 return o
root=bpy.data.objects.new('DRAGON flight',None);bpy.context.collection.objects.link(root)
# Layered dorsal carapace around a sinuous body; each segment is an animated vertebra.
segments=[]
for i in range(27):
 u=i/26;x=-u*13;r=(.65*(1-u)**.55+.045);y=sin(u*pi*2)*1.65;z=sin(u*pi*2+.5)*.8
 bone=bpy.data.objects.new('Vertebra_%02d'%i,None);bpy.context.collection.objects.link(bone);bone.parent=root;bone.location=(x,y,z);segments.append((bone,u,r))
 uv('Hide',(0,0,0),(.39,r,r*.9),dark,parent=bone)
 # Small overlapping shield scales, not a handful of giant plates.
 parts=[]
 for row in range(4):
  for j in range(13):
   a=(j+(row%2)*.5)*2*pi/13;sh=uv('Individual scale',(-.24+row*.16,r*cos(a)*.96,r*sin(a)*.88),(.145,.13*r/.65,.055),jade if random.random()>.13 else gold,8,6,bone);sh.rotation_euler[0]=a-pi/2;parts.append(sh)
 bpy.ops.object.select_all(action='DESELECT')
 for part in parts:part.select_set(True)
 bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();bpy.context.object.name='Layered carapace_%02d'%i
 horn('Dorsal spine',[(0,0,r*.83),(-.25,0,r+.38),(-.55,0,r+.7)], [.14,.1,.003],gold,bone)
 uv('Ventral plate',(.06,0,-r*.85),(.36,r*.65,.12),belly,12,8,bone)
# Recognisable long draconic skull, not a sphere.
head=bpy.data.objects.new('Dragon skull',None);bpy.context.collection.objects.link(head);head.parent=root;head.location=(.35,0,.25)
uv('Cranium',(0,0,0),(1.05,.64,.68),jade,24,16,head)
uv('Long muzzle',(1.0,0,-.10),(.85,.43,.36),jade,24,12,head)
uv('Lower jaw',(1.05,0,-.46),(.86,.37,.12),gold,20,10,head)
uv('Nasal crown',(1.55,0,.05),(.30,.41,.25),jade,20,12,head)
for k in range(10):
 for side in [-1,1]:
  uv('Facial scale',(-.55+k*.18,side*.49,.36+sin(k)*.05),(.17,.085,.07),jade,10,6,head)
for side in [-1,1]:
 uv('Cheek',(.18,side*.52,-.13),(.65,.18,.42),gold,parent=head)
 uv('Brow',(.51,side*.53,.38),(.49,.20,.14),jade,parent=head)
 uv('Amber eye',(.66,side*.585,.20),(.15,.065,.10),eye,20,12,head)
 uv('Vertical pupil',(.68,side*.645,.20),(.029,.019,.08),black,parent=head)
 uv('Nostril',(1.58,side*.30,-.02),(.14,.05,.075),black,parent=head)
 horn('Crown horn',[(-.32,side*.39,.47),(-.7,side*.57,1.15),(-1.15,side*.72,1.65),(-1.7,side*.81,1.82)],[.23,.17,.09,.002],ivory,head)
 horn('Antler branch',[(-.8,side*.6,1.25),(-.63,side*.82,1.62),(-.78,side*1.0,1.96)],[.10,.06,.001],ivory,head)
 curve('Whisker',[(1.5,side*.33,-.2),(1.3,side*1.1,-.13),(.4,side*1.75,.05),(-.5,side*1.95,.45)],.025,gold,head)
 for k in range(5):horn('Cheek frill',[(-.45-k*.13,side*.48,.15-k*.12),(-1.2-k*.12,side*(.75+k*.05),.4-k*.17),(-1.8-k*.09,side*.6,.7-k*.25)],[.13,.10,.001],gold,head)
 for k in range(6):horn('Fang',[(.55+k*.19,side*.32,-.25),(.6+k*.19,side*.32,-.40)],[.055,.001],ivory,head)
curve('Mouth crease',[(.45,-.405,-.29),(1.1,-.405,-.3),(1.8,-.22,-.25)],.022,black,head)
# Four articulated limbs and hooked talons.
for idx in [4,15]:
 bone=segments[idx][0]
 for side in [-1,1]:
  horn('Limb',[(0,side*.4,0),(.25,side*1.1,-.35),(.65,side*1.25,-.7),(.85,side*1.1,-1.0)],[.24,.20,.12,.12],jade,bone)
  for j in range(3):horn('Talon',[(.8,side*(1+.15*j),-.95),(1.15,side*(1+.15*j),-1.1),(1.42,side*(.98+.15*j),-.98)],[.10,.06,.002],ivory,bone)
# Basalt spires and broken volcanic ground.
bpy.ops.mesh.primitive_plane_add(size=160,location=(0,0,-4));bpy.context.object.data.materials.append(rock)
for i in range(42):
 x=random.uniform(-24,20);y=random.uniform(-15,22)
 if -15<x<4 and abs(y)<3:continue
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=1,location=(x,y,-3.3));o=bpy.context.object;o.name='Basalt outcrop';o.scale=(random.uniform(1,3),random.uniform(1,3),random.uniform(1,5));o.rotation_euler=(random.random(),random.random(),random.random());o.data.materials.append(rock)
 for v in o.data.vertices:v.co*=random.uniform(.76,1.25)
 for poly in o.data.polygons:poly.use_smooth=True
# Atmospheric volume. Low density, bounded to avoid endless ray marching.
vol=bpy.data.materials.new('Silver mist');vol.use_nodes=True;n=vol.node_tree.nodes;n.clear();out=n.new('ShaderNodeOutputMaterial');p=n.new('ShaderNodeVolumePrincipled');p.inputs['Density'].default_value=.004;p.inputs['Color'].default_value=(.46,.59,.65,1);p.inputs['Anisotropy'].default_value=.3;vol.node_tree.links.new(p.outputs['Volume'],out.inputs['Volume'])
bpy.ops.mesh.primitive_cube_add(size=2,location=(-2,6,3));o=bpy.context.object;o.name='Valley atmosphere';o.scale=(40,35,16);o.data.materials.append(vol)
def area(name,loc,power,color,size):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.color=color;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((-4,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
area('Moon silver key',(2,-10,15),3600,(.55,.8,1),9);area('Sunrise rim',(-7,8,13),6000,(1,.55,.22),8);area('Face bounce',(10,-5,3),1000,(.5,1,.8),6)
d=bpy.data.lights.new('Sun','SUN');d.energy=1.4;d.angle=.18;d.color=(1,.67,.38);o=bpy.data.objects.new('Sun',d);bpy.context.collection.objects.link(o);o.rotation_euler=(.4,-.7,-.4)
bpy.ops.object.camera_add(location=(10,-18,6));cam=bpy.context.object;sc.camera=cam;cam.data.lens=49
for f in range(1,241,4):
 t=(f-1)/239;root.location=(t*2,0,t*t*13);root.rotation_euler=(0,-t*.55,t*.2);root.keyframe_insert('location',frame=f);root.keyframe_insert('rotation_euler',frame=f)
 for bone,u,r in segments:
  bone.location=(-u*13,sin(u*pi*2-t*3)*1.65,sin(u*pi*2+.5-t*2)*.8);bone.rotation_euler=(0,.13*cos(u*2*pi-t*2),-.55*cos(u*2*pi-t*3));bone.keyframe_insert('location',frame=f);bone.keyframe_insert('rotation_euler',frame=f)
 cam.location=(9-t*4,-19-t*2,5+t*13);target=Vector((-4+t*2,0,1+t*t*12));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f)
for ob in bpy.data.objects:
 if ob.animation_data and ob.animation_data.action:
  for fc in ob.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
sc.frame_set(60);sc.render.filepath=OUT+'/preview.png';bpy.ops.wm.save_as_mainfile(filepath=OUT+'/Mio_Dragon_Ascension.blend');start=time.time();bpy.ops.render.render(write_still=True);print('RENDER_SECONDS',time.time()-start)
