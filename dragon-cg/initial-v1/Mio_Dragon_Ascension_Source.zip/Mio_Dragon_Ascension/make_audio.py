import numpy as np,wave,os
rate=48000;duration=8;n=rate*duration;t=np.arange(n)/rate;rng=np.random.default_rng(1976)
def band_noise(lo,hi):
 f=np.fft.rfftfreq(n,1/rate);a=np.fft.rfft(rng.normal(size=n));shape=np.exp(-.5*((np.log(np.maximum(f,1))-np.log((lo*hi)**.5))/(np.log(hi/lo)/3))**2);v=np.fft.irfft(a*shape,n);return v/(np.std(v)+1e-9)
fade=np.minimum(t/1.2,1)*np.minimum((duration-t)/1.5,1)
rumble=band_noise(28,130)*.09
wind=band_noise(300,2800)*(.014+.035*(t/duration)**2)
boom=np.sin(2*np.pi*(47*t-1.6*t*t))*np.exp(-t*1.5)*.15
music=np.zeros(n)
for freq,amp in [(55,.04),(82.4069,.025),(110,.018),(164.8138,.012)]:music+=np.sin(2*np.pi*freq*t)*(1-np.exp(-t*.6))*amp
whoosh=band_noise(180,3500)*(np.exp(-((t-3.8)/.7)**2)*.065+np.exp(-((t-6.1)/1.1)**2)*.08)
y=(rumble+wind+boom+music+whoosh)*fade
left=y.copy();right=y.copy()
for delay,gain in [(.17,.12),(.36,.08),(.61,.05)]:
 d=int(delay*rate);right[d:]+=y[:-d]*gain;left[d:]+=y[:-d]*gain*.7
st=np.stack((left,right),1);st*=.65/max(np.max(np.abs(st)),.001)
path=os.path.dirname(__file__)+'/dragon_sound.wav'
with wave.open(path,'wb')as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(rate);w.writeframes((st*32767).astype('<i2').tobytes())
print(path,'peak',np.max(np.abs(st)),'RMS',np.sqrt(np.mean(st**2)))
